package com.llele.favornote.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;

import java.util.List;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.SearchViewHolder> {
    List<FavorBean> data;

    public SearchResultAdapter(List<FavorBean> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SearchViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_search_result,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull SearchViewHolder holder, int position) {
        if (data.get(position).getType() == 1){
            holder.type.setImageResource(R.mipmap.ic_type_cost);
        }else if (data.get(position).getType() == 2){
            holder.type.setImageResource(R.mipmap.ic_type_income);
        }
        holder.date.setText(data.get(position).getDate());
        holder.name.setText(data.get(position).getName());
        holder.money.setText("¥ "+data.get(position).getMoney());
        holder.reason.setText(data.get(position).getReason());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class SearchViewHolder extends RecyclerView.ViewHolder{
        ImageView type;
        TextView name,reason,money,date;
        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            type = itemView.findViewById(R.id.type_searchResult);
            name = itemView.findViewById(R.id.name_searchResult);
            reason = itemView.findViewById(R.id.reason_searchResult);
            money = itemView.findViewById(R.id.money_searchResult);
            date = itemView.findViewById(R.id.date_searchResult);
        }
    }
}
