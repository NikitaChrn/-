package com.llele.favornote.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.KeyboardUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.adapter.FavorListAdapter;
import com.llele.favornote.adapter.ReasonAdapter;
import com.llele.favornote.adapter.SearchResultAdapter;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.widget.MyPopup;
import com.llele.favornote.widget.SearchPopup;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupPosition;
import com.lxj.xpopup.interfaces.SimpleCallback;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    private static final String TAG = "SearchActivity";
    private EditText searchEdt;
    private RecyclerView recyclerView;
    private SearchResultAdapter adapter;
    private String input;
    private boolean isShowPopup = false;
    private SearchPopup mPopup;
    private ImageView triangle;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        triangle = findViewById(R.id.icon_search_layout);
        findViewById(R.id.back_search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
//        findViewById(R.id.ll_search_layout).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                showPartShadow(v);
//            }
//        });
        recyclerView = findViewById(R.id.recycler_search);
        searchEdt = findViewById(R.id.searchEdt);
        searchEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                input = s.toString();
            }
        });
        findViewById(R.id.gotoSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                KeyboardUtils.hideSoftInput(SearchActivity.this);
                if (TextUtils.isEmpty(input)) {
                    ToastUtils.showLong("请输入内容");
                    return;
                }
                List<FavorBean> data = DBHelper.getInstance().queryRecordByName(input);
                if (data.size() == 0) {
                    ToastUtils.showLong("没有查到记录！");
                } else {
                    adapter = new SearchResultAdapter(data);
                    recyclerView.setAdapter(adapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(SearchActivity.this));

                }

            }
        });

    }


    private void showPartShadow(final View v) {
        mPopup = (SearchPopup) new XPopup.Builder(SearchActivity.this)
                .atView(v)
                .popupPosition(PopupPosition.Bottom)
                .setPopupCallback(new SimpleCallback() {
                    @Override
                    public void onShow(BasePopupView popupView) {
                        isShowPopup = true;
                        triangle.setImageResource(R.mipmap.icon_triangle_up);
                    }

                    @Override
                    public void onDismiss(BasePopupView popupView) {
                        isShowPopup = false;
                        triangle.setImageResource(R.mipmap.icon_triangle_down);
                    }
                })
                .asCustom(new SearchPopup(SearchActivity.this));
        mPopup.show();
        mPopup.setOnItemClick(new SearchPopup.OnItemClick() {
            @Override
            public void click(int position) {
                if (mPopup != null && mPopup.isShow()) {
                    mPopup.dismiss();
                }
//                final FavorListAdapter adapter = new FavorListAdapter(da);
//                recyclerView.setAdapter(adapter);
//                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            }
        });
    }
}