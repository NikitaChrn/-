package com.llele.favornote.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.adapter.TypeAdapter;
import com.llele.favornote.constants.Api;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.OnInputConfirmListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ManagerTypeActivity extends AppCompatActivity {
    private static final String TAG = "ManagerTypeActivity";
    private int type = 1;
    private List<String> data = new ArrayList<>();
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_type);
        type = getIntent().getIntExtra("type", 1);
        findViewById(R.id.back_common_header).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView commonTitle = findViewById(R.id.title_common_header);
        commonTitle.setText(type == 1 ? "亲友管理" : "事件管理");
        ImageView rightImg = findViewById(R.id.right_common_header);
        rightImg.setImageResource(R.mipmap.ic_title_add);
        rightImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new XPopup.Builder(ManagerTypeActivity.this).asInputConfirm("添加类型", "请输入类型。",
                        new OnInputConfirmListener() {
                            @Override
                            public void onConfirm(String text) {
                                if (TextUtils.isEmpty(text)) {
                                    ToastUtils.showLong("内容不能为空");
                                    return;
                                }
                                String dataStr = SPUtils.getInstance().getString(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE);
                                Log.e(TAG, "onConfirm: " + dataStr);
//                                data.addAll(Arrays.asList(dataStr.split(",")));
                                dataStr = dataStr + text + ",";
                                Log.e(TAG, "onConfirm: " + dataStr);
                                SPUtils.getInstance().put(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE, dataStr);
                                onResume();
                            }
                        })
                        .show();
            }
        });
        recyclerView = findViewById(R.id.recycler_editType);
        findViewById(R.id.rename_managerType).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adapter.getCheckedPosition() == -1){
                    ToastUtils.showLong("还未选择，请选择需要重命名的事件");
                    return;
                }
                new XPopup.Builder(ManagerTypeActivity.this).asInputConfirm("重命名类型", "请输入名称",
                        new OnInputConfirmListener() {
                            @Override
                            public void onConfirm(String text) {
                                if (TextUtils.isEmpty(text)) {
                                    ToastUtils.showLong("内容不能为空");
                                    return;
                                }
                                data.set(adapter.getCheckedPosition(),text);
                                String[] strings = new String[data.size()];
                                String[] dataReason = data.toArray(strings);
                                String s = "";
                                for (String str : dataReason) {
                                    s+=str+",";
                                }
                                SPUtils.getInstance().put(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE,s);
                                Log.e(TAG, "onConfirm: " + s);
                                onResume();
                            }
                        })
                        .show();
            }
        });
        findViewById(R.id.delete_managerType).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adapter.getCheckedPosition() == -1){
                    ToastUtils.showLong("还未选择，请选择需要删除的事件");
                    return;
                }
                new XPopup.Builder(ManagerTypeActivity.this).asConfirm("提示", "确认删除该类型？",
                        new OnConfirmListener() {
                            @Override
                            public void onConfirm() {
                                data.remove(adapter.getCheckedPosition());
                                String[] strings = new String[data.size()];
                                String[] dataReason = data.toArray(strings);
                                String s = "";
                                for (String str : dataReason) {
                                    s+=str+",";
                                }
                                SPUtils.getInstance().put(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE,s);
                                Log.e(TAG, "onConfirm: " + s);
                                onResume();
                            }
                        })
                        .show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        data.clear();
        String dataStr = SPUtils.getInstance().getString(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE);
        data.addAll(Arrays.asList(dataStr.split(",")));
        handler.sendEmptyMessage(101);
    }

    TypeAdapter adapter;
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 101) {
                adapter = new TypeAdapter(data);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(ManagerTypeActivity.this));
            }
        }
    };
}