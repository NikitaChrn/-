package com.llele.favornote.bean;

import java.io.Serializable;

public class ReasonBean implements Serializable {
    String date;
    String reason;

    public ReasonBean() {
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
