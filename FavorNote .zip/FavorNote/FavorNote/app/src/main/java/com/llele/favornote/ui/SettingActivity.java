package com.llele.favornote.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.llele.favornote.R;

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        findViewById(R.id.back_common_header).setOnClickListener(this);
        TextView commonTitle = findViewById(R.id.title_common_header);
        commonTitle.setText("设置");
        findViewById(R.id.ll_friendType_setting).setOnClickListener(this);
        findViewById(R.id.ll_statistics_setting).setOnClickListener(this);
        findViewById(R.id.ll_reason_setting).setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.back_common_header:
                finish();
                break;
            case R.id.ll_friendType_setting:
                intent = new Intent(SettingActivity.this,ManagerTypeActivity.class);
                intent.putExtra("type",1);
                startActivity(intent);
                break;
            case R.id.ll_statistics_setting:
                intent = new Intent(SettingActivity.this,StatisticsActivity.class);
                startActivity(intent);
                break;
            case R.id.ll_reason_setting:
                intent = new Intent(SettingActivity.this,ManagerTypeActivity.class);
                intent.putExtra("type",2);
                startActivity(intent);
                break;
        }
    }
}