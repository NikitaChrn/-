package com.llele.favornote.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.adapter.ChoseRecordTypeAdapter;
import com.llele.favornote.constants.Api;
import com.llele.favornote.utils.StatusBarUtil;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnInputConfirmListener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ChoseTypeActivity extends AppCompatActivity{
    private static final String TAG = "ChoseTypeActivity";
    private int type = 1;
    private RecyclerView choseType;
    private ChoseRecordTypeAdapter adapter;
    private List<String> data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_type);
        type = getIntent().getIntExtra("type",1);
        StatusBarUtil.setStatusBarMode(this, false, R.color.colorAccent);
        findViewById(R.id.back_common_header).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ImageView rightImg = findViewById(R.id.right_common_header);
        rightImg.setImageResource(R.mipmap.ic_title_add);
        rightImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new XPopup.Builder(ChoseTypeActivity.this).asInputConfirm("添加类型", "请输入类型。",
                        new OnInputConfirmListener() {
                            @Override
                            public void onConfirm(String text) {
                                if (TextUtils.isEmpty(text)){
                                    ToastUtils.showLong("内容不能为空");
                                    return;
                                }
                                String dataStr = SPUtils.getInstance().getString(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE);
                                Log.e(TAG, "onConfirm: " +dataStr );
//                                data.addAll(Arrays.asList(dataStr.split(",")));
                                dataStr = dataStr +text+",";
                                Log.e(TAG, "onConfirm: " +dataStr );
                                SPUtils.getInstance().put(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE,dataStr);
                                onResume();
                            }
                        })
                        .show();
            }
        });
        TextView title = findViewById(R.id.title_common_header);
        title.setText(type == 1 ? "亲友类型" : "事件类型");
        choseType = findViewById(R.id.recycler_choseType);

    }

    @Override
    protected void onResume() {
        super.onResume();
        data.clear();
        String dataStr = SPUtils.getInstance().getString(type == 1 ? Api.SP_KEYS_FRIEND_TYPE : Api.SP_KEYS_REASON_TYPE);
        data.addAll(Arrays.asList(dataStr.split(",")));
        handler.sendEmptyMessage(101);

    }


    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 101){
                ChoseRecordTypeAdapter adapter = new ChoseRecordTypeAdapter(data);
                choseType.setAdapter(adapter);
                choseType.setLayoutManager(new GridLayoutManager(ChoseTypeActivity.this,5));
                adapter.setOnItemClick(new ChoseRecordTypeAdapter.OnItemClick() {
                    @Override
                    public void click(int position) {
                        Intent intent = new Intent();
                        intent.putExtra("type",data.get(position));
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                });
            }
        }
    };
}