package com.llele.favornote.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;

import java.util.List;

public class CostListAdapter extends RecyclerView.Adapter<CostListAdapter.CostListViewHolder> {

    List<FavorBean> data;

    public CostListAdapter(List<FavorBean> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public CostListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CostListViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.cost_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final CostListViewHolder holder, final int position) {
        if (position == 0) {
            holder.label1.setVisibility(View.VISIBLE);
            holder.label2.setVisibility(View.GONE);
        } else {
            holder.label1.setVisibility(View.GONE);
            holder.label2.setVisibility(View.VISIBLE);
        }
        holder.date.setText(data.get(position).getDate().split("-")[1] + "月" + data.get(position).getDate().split("-")[2] + "号");
        holder.year.setText(data.get(position).getYear());
        holder.pType.setText("给我的" + data.get(position).getPtype()+" ");
        holder.name.setText(data.get(position).getName());
        holder.reason.setText(" " + data.get(position).getReason());
        holder.money.setText(" 随礼" + data.get(position).getMoney() + "元");
        holder.remarks.setText("备注：" + data.get(position).getRemarks());
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                onItemLongClick.onLongClick(position);
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class CostListViewHolder extends RecyclerView.ViewHolder {
        TextView name, date, year, reason, remarks, money,pType;
        ImageView label1;
        LinearLayout label2;

        public CostListViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name_costItem);
            date = itemView.findViewById(R.id.date_costItem);
            year = itemView.findViewById(R.id.year_costItem);
            remarks = itemView.findViewById(R.id.remarks_costItem);
            reason = itemView.findViewById(R.id.reason_costItem);
            money = itemView.findViewById(R.id.money_costItem);
            label1 = itemView.findViewById(R.id.label_1_costItem);
            label2 = itemView.findViewById(R.id.label_2_costItem);
            pType = itemView.findViewById(R.id.peopleType_costItem);
        }
    }

    public interface OnItemLongClick{
        void onLongClick(int position);
    }

    OnItemLongClick onItemLongClick;

    public void setOnItemLongClick(OnItemLongClick onItemLongClick){
        this.onItemLongClick = onItemLongClick;
    }
}
