package com.llele.favornote.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.bean.RecordTypeBean;

import java.util.List;

public class ChoseRecordTypeAdapter extends RecyclerView.Adapter<ChoseRecordTypeAdapter.ChoseTypeViewHolder> {
    private List<String> data;

    public ChoseRecordTypeAdapter(List<String> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ChoseTypeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ChoseTypeViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chose_type,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ChoseTypeViewHolder holder, final int position) {
        holder.name.setText(data.get(position));
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                itemClick.click(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class ChoseTypeViewHolder extends RecyclerView.ViewHolder{
        TextView name;
        public ChoseTypeViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name_choseType);
        }
    }

    public interface OnItemClick{
        void click(int position);
    }

    OnItemClick itemClick;

    public void setOnItemClick(OnItemClick onItemClick){
        this.itemClick = onItemClick;
    }
}
