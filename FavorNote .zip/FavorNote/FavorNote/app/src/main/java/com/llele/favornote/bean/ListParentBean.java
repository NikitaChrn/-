package com.llele.favornote.bean;

import java.io.Serializable;
import java.util.List;

public class ListParentBean implements Serializable {
    private int count;
    private String date;
    private List<FavorBean> child;

    public ListParentBean() {
    }

    public List<FavorBean> getChild() {
        return child;
    }

    public void setChild(List<FavorBean> child) {
        this.child = child;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
