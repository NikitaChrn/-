package com.llele.favornote.widget;

import android.content.Context;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.adapter.ReasonAdapter;
import com.llele.favornote.bean.FavorType;
import com.lxj.xpopup.impl.PartShadowPopupView;

import java.util.List;

public class SearchPopup extends PartShadowPopupView {

    private Context context;

    public SearchPopup(@NonNull Context context) {
        super(context);
        this.context = context;
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.popuplayout_search;
    }

    @Override
    protected void onCreate() {
        super.onCreate();
        findViewById(R.id.searchType1).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.click(1);
            }
        });
        findViewById(R.id.searchType2).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.click(1);
            }
        });
    }

    public interface OnItemClick{
        void click(int position);
    }

    OnItemClick onItemClick;

    public void setOnItemClick(OnItemClick onItemClick){
        this.onItemClick = onItemClick;
    }



    @Override
    protected void onShow() {
        super.onShow();
        Log.e("tag", "CustomPartShadowPopupView onShow");
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        Log.e("tag", "CustomPartShadowPopupView onDismiss");
    }
}
