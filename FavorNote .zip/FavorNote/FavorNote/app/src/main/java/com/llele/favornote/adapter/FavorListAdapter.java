package com.llele.favornote.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;

import java.util.List;

public class FavorListAdapter extends RecyclerView.Adapter<FavorListAdapter.FavorViewHolder> {

    List<FavorBean> data;

    public FavorListAdapter(List<FavorBean> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public FavorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FavorViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_favor,null));
    }

    @Override
    public void onBindViewHolder(@NonNull FavorViewHolder holder, final int position) {
        holder.name.setText(data.get(position).getName());
        holder.date.setText(data.get(position).getDate());
        holder.money.setText("¥ "+data.get(position).getMoney());
        holder.reason.setText(data.get(position).getReason());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.onClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class FavorViewHolder extends RecyclerView.ViewHolder{
        TextView name,reason,money,date;
        public FavorViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.favor_name);
            reason = itemView.findViewById(R.id.favor_reason);
            money = itemView.findViewById(R.id.favor_money);
            date = itemView.findViewById(R.id.favor_date);
        }
    }

    public interface OnItemClick{
        void onClick(int position);
    }

    OnItemClick onItemClick;

    public void setOnItemClick(OnItemClick onItemClick){
        this.onItemClick = onItemClick;
    }

}
