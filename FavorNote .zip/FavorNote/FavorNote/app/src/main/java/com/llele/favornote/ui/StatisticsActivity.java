package com.llele.favornote.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.llele.favornote.R;
import com.llele.favornote.ui.fragment.CostStaFragment;
import com.llele.favornote.ui.fragment.IncomeStaFragment;
import com.llele.favornote.utils.StatusBarUtil;

public class StatisticsActivity extends AppCompatActivity implements View.OnClickListener {
    TextView costTabTv,incomeTabTv;
    private FragmentManager fragmentManager;
    private FragmentTransaction mTransaction;//fragment事务
    private IncomeStaFragment incomeFragment;
    private CostStaFragment costFragment;
    private boolean isCommit = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
        StatusBarUtil.setStatusBarMode(this, false, R.color.colorAccent);
        findViewById(R.id.back_common_header).setOnClickListener(this);
        costTabTv = findViewById(R.id.tab_cost_sta);
        costTabTv.setOnClickListener(this);
        incomeTabTv = findViewById(R.id.tab_income_sta);
        incomeTabTv.setOnClickListener(this);
        fragmentManager = getSupportFragmentManager();
        costTabTv.performClick();

    }


    @Override
    public void onClick(View v) {
        mTransaction = fragmentManager.beginTransaction();
        hideFragment(mTransaction);
        switch (v.getId()){
            case R.id.back_common_header:
                isCommit = false;
                finish();
                break;
            case R.id.tab_cost_sta:
                isCommit = true;
                if (costFragment == null){
                    costFragment = new CostStaFragment();
                    mTransaction.add(R.id.frame_statistics,costFragment);
                }else {
                    mTransaction.show(costFragment);
                    costFragment.onResume();
                }
                costTabTv.setTextColor(getResources().getColor(R.color.colorAccent));
                costTabTv.setBackground(getResources().getDrawable(R.drawable.bg_16_ffffff_left));
                incomeTabTv.setTextColor(getResources().getColor(R.color.white));
                incomeTabTv.setBackground(getResources().getDrawable(R.drawable.bg_16_ffffff1_right));
                break;
            case R.id.tab_income_sta:
                isCommit = true;
                if (incomeFragment == null){
                    incomeFragment = new IncomeStaFragment();
                    mTransaction.add(R.id.frame_statistics,incomeFragment);
                }else {
                    mTransaction.show(incomeFragment);
                    incomeFragment.onResume();
                }
                incomeTabTv.setTextColor(getResources().getColor(R.color.colorAccent));
                incomeTabTv.setBackground(getResources().getDrawable(R.drawable.bg_16_39a287_left));
                costTabTv.setTextColor(getResources().getColor(R.color.white));
                costTabTv.setBackground(getResources().getDrawable(R.drawable.bg_16_39a2871_right));
                break;
        }
        if (isCommit) mTransaction.commit();
    }

    private void hideFragment(FragmentTransaction fragmentTransaction) {
        //如果此fragment不为空的话就隐藏起来
        if (incomeFragment != null) {
            fragmentTransaction.hide(incomeFragment);
        }
        if (costFragment != null) {
            fragmentTransaction.hide(costFragment);
        }
    }
}
