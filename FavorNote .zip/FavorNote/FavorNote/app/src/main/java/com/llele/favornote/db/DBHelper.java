package com.llele.favornote.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.llele.favornote.App;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.constants.Api;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME_ARTICLE = "note.db";
    public static final String TAB_NAME_FAVOR = "favor";

    private static DBHelper dbHelper = null;

    public static DBHelper getInstance() {
        // 先判断实例是否存在，若不存在再对类对象进行加锁处理
        if (dbHelper == null) {
            synchronized (DBHelper.class) {
                if (dbHelper == null) {
                    dbHelper = new DBHelper(App.getInstance());
                }
            }
        }
        return dbHelper;
    }

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME_ARTICLE, null, 3);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
//        db.execSQL(" create table "+ TAB_NAME_FAVOR+"("+"_id integer primary key autoincrement, title text,content text, date text, type text, money text,icon INTEGER,icon_name text )");
        db.execSQL(" create table " + TAB_NAME_FAVOR + "(" + "_id integer primary key autoincrement, date text, name text, money text,reason text,type text,year text,remarks text,ptype text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TAB_NAME_FAVOR);
        onCreate(db);
    }

    //根据日期查找
    public List<FavorBean> queryRecordByDate(String date) {
        List<FavorBean> data = new ArrayList<>();
        Cursor cursor = getWritableDatabase().query(TAB_NAME_FAVOR, null, "date=?", new String[]{date}, null, null, null);
        while (cursor.moveToNext()) {
            int mType = cursor.getInt(cursor.getColumnIndex("type"));
            String mName = cursor.getString(cursor.getColumnIndex("name"));
            String mDate = cursor.getString(cursor.getColumnIndex("date"));
            String money = cursor.getString(cursor.getColumnIndex("money"));
            String reason = cursor.getString(cursor.getColumnIndex("reason"));
            String year = cursor.getString(cursor.getColumnIndex("year"));
            String remarks = cursor.getString(cursor.getColumnIndex("remarks"));
            String pType = cursor.getString(cursor.getColumnIndex("ptype"));
            int _id = cursor.getInt(cursor.getColumnIndex("_id"));
            FavorBean bean = new FavorBean();
            bean.setDate(mDate);
            bean.setMoney(money);
            bean.setName(mName);
            bean.setType(mType);
            bean.setReason(reason);
            bean.setYear(year);
            bean.setRemarks(remarks);
            bean.setPtype(pType);
            bean.set_id(_id);
            data.add(bean);
        }
        cursor.close();
        return data;
    }

    public List<FavorBean> queryRecordByName(String name) {
        List<FavorBean> data = new ArrayList<>();
        Cursor cursor = getWritableDatabase().query(TAB_NAME_FAVOR, null, "name=?", new String[]{name}, null, null, null);
        while (cursor.moveToNext()) {
            int mType = cursor.getInt(cursor.getColumnIndex("type"));
            String mName = cursor.getString(cursor.getColumnIndex("name"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String money = cursor.getString(cursor.getColumnIndex("money"));
            String reason = cursor.getString(cursor.getColumnIndex("reason"));
            String year = cursor.getString(cursor.getColumnIndex("year"));
            String remarks = cursor.getString(cursor.getColumnIndex("remarks"));
            String pType = cursor.getString(cursor.getColumnIndex("ptype"));
            int _id = cursor.getInt(cursor.getColumnIndex("_id"));
            FavorBean bean = new FavorBean();
            bean.setDate(date);
            bean.setMoney(money);
            bean.setName(mName);
            bean.setType(mType);
            bean.setReason(reason);
            bean.setYear(year);
            bean.setRemarks(remarks);
            bean.setPtype(pType);
            bean.set_id(_id);
            data.add(bean);
        }
        cursor.close();
        return data;
    }

    //type: 1 随礼 , 2 收礼
    public List<FavorBean> queryAllFavorByType(int type) {
        List<FavorBean> list = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(TAB_NAME_FAVOR, null, null, null, null, null, "year" + " asc");
        while (cursor.moveToNext()) {
            int mType = cursor.getInt(cursor.getColumnIndex("type"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String money = cursor.getString(cursor.getColumnIndex("money"));
            String reason = cursor.getString(cursor.getColumnIndex("reason"));
            String year = cursor.getString(cursor.getColumnIndex("year"));
            String remarks = cursor.getString(cursor.getColumnIndex("remarks"));
            String pType = cursor.getString(cursor.getColumnIndex("ptype"));
            int _id = cursor.getInt(cursor.getColumnIndex("_id"));
            FavorBean bean = new FavorBean();
            bean.setDate(date);
            bean.setMoney(money);
            bean.setName(name);
            bean.setType(mType);
            bean.setReason(reason);
            bean.setYear(year);
            bean.setRemarks(remarks);
            bean.setPtype(pType);
            bean.set_id(_id);
            if (type == 1 && mType == 1) {
                list.add(bean);
            } else if (type == 2 && mType == 2) {
                list.add(bean);
            }
        }
        cursor.close();
        return list;
    }

    public List<FavorBean> queryAllFavor() {
        List<FavorBean> list = new ArrayList<>();
        Cursor cursor = getReadableDatabase().query(TAB_NAME_FAVOR, null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            int mType = cursor.getInt(cursor.getColumnIndex("type"));
            String name = cursor.getString(cursor.getColumnIndex("name"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String money = cursor.getString(cursor.getColumnIndex("money"));
            String reason = cursor.getString(cursor.getColumnIndex("reason"));
            String year = cursor.getString(cursor.getColumnIndex("year"));
            String remarks = cursor.getString(cursor.getColumnIndex("remarks"));
            String pType = cursor.getString(cursor.getColumnIndex("ptype"));
            int _id = cursor.getInt(cursor.getColumnIndex("_id"));
            FavorBean bean = new FavorBean();
            bean.setDate(date);
            bean.setMoney(money);
            bean.setName(name);
            bean.setType(mType);
            bean.setReason(reason);
            bean.setYear(year);
            bean.setRemarks(remarks);
            bean.setPtype(pType);
            bean.set_id(_id);
            list.add(bean);
        }
        cursor.close();
        return list;
    }

    public boolean insertFavor(FavorBean bean) {
        ContentValues values = new ContentValues();
        values.put("name", bean.getName());
        values.put("reason", bean.getReason());
        values.put("date", bean.getDate());
        values.put("money", bean.getMoney());
        values.put("type", bean.getType());
        values.put("remarks", bean.getRemarks());
        values.put("ptype", bean.getPtype());
        values.put("year", bean.getYear());
        long rowId = getWritableDatabase().insert(TAB_NAME_FAVOR, null, values);
        if (rowId > 0) {
            return true;
        }
        return false;
    }

    public boolean deleteRecordById(int id) {
        int result = getWritableDatabase().delete(TAB_NAME_FAVOR, "_id" + "=?", new String[]{"" + id});
        if (result > 0) {
            return true;
        }
        return false;
    }

//    public boolean updateArticle(NewsListBean bean){
//        ContentValues values = new ContentValues();
//        values.put("link", bean.getLink());
//        values.put("collect",bean.isCollected());
//        values.put("zan",bean.isZan());
//        values.put("comment",bean.getComment());
//        values.put("title",bean.getComment());
//        int result = getWritableDatabase().update(TAB_NAME_FAVOR, values,"link"+"=?",new String[]{bean.getLink()+""});
//        if (result > 0) {
//            return true;
//        }
//        return false;
//    }
}
