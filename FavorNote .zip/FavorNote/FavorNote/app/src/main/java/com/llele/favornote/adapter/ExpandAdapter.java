package com.llele.favornote.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.bean.ListParentBean;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.ui.AddRecordActivity;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;

import java.util.ArrayList;
import java.util.List;

public class ExpandAdapter extends BaseExpandableListAdapter {
    List<ListParentBean> parentList;
    Context context;

    public ExpandAdapter(List<ListParentBean> parentList, Context context) {
        this.parentList = parentList;
        this.context = context;
    }

    @Override
    public int getGroupCount() {
        return parentList.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return parentList.get(groupPosition).getChild().size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return parentList.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return parentList.get(groupPosition).getChild().get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        GroupHolder viewHolder;
        if (convertView == null) {
            viewHolder = new GroupHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.eplistv_test_group, parent,false);
            //对viewHolder的属性进行赋值
            viewHolder.titleGroup = convertView.findViewById(R.id.title_group);
            viewHolder.numGroup = convertView.findViewById(R.id.num_group);
            viewHolder.iconGroup = convertView.findViewById(R.id.icon_group);
            //使用setTag缓存起来方便多次重用
            convertView.setTag(viewHolder);
        } else { //如果缓存池中有对应的缓存，则直接通过getTag取出viewHolder
            viewHolder = (GroupHolder) convertView.getTag();
        }
        viewHolder.titleGroup.setText(parentList.get(groupPosition).getDate()+"年");
        viewHolder.numGroup.setText(""+parentList.get(groupPosition).getCount());
        viewHolder.iconGroup.setImageResource(isExpanded ? R.mipmap.icon_expand_right : R.mipmap.icon_expand_down);
        return convertView;
    }

    @Override
    public View getChildView(final int groupPosition, final int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChildHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ChildHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.eplistv_test_child, parent,false);
            //对viewHolder的属性进行赋值
            viewHolder.monthChild = convertView.findViewById(R.id.month_child);
            viewHolder.nameChild = convertView.findViewById(R.id.name_child);
            viewHolder.moneyChild = convertView.findViewById(R.id.money_child);
            viewHolder.dayChild = convertView.findViewById(R.id.day_child);
            //使用setTag缓存起来方便多次重用
            convertView.setTag(viewHolder);
        } else { //如果缓存池中有对应的缓存，则直接通过getTag取出viewHolder
            viewHolder = (ChildHolder) convertView.getTag();
        }
        final FavorBean info = parentList.get(groupPosition).getChild().get(childPosition);
        String[] strs = info.getDate().split("-");
        viewHolder.monthChild.setText(strs[1]+"月");
        viewHolder.dayChild.setText(strs[2]+"日");
        viewHolder.nameChild.setText(info.getName());
        viewHolder.moneyChild.setText("￥"+info.getMoney());
        viewHolder.nameChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClick.click(info.get_id(),groupPosition);
            }
        });
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }

    static class GroupHolder {                //用于缓存Group控件
        public TextView titleGroup, numGroup;
        public ImageView iconGroup;
    }

    static class ChildHolder {                //用于缓存items控件
        public TextView monthChild, nameChild, moneyChild,dayChild;
    }

    public interface OnItemClick{
        void click(int id,int groupPosition);
    }

    OnItemClick onItemClick;

    public void setOnItemClick(OnItemClick click){
        this.onItemClick = click;
    }
}
