package com.llele.favornote.utils;


import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.llele.favornote.App;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;


/**
 * 仿IOS的弹出框
 */


public class AddFavorView extends Dialog {

    private ClickListenerInterface clickListenerInterface;
    private Context context;
    private String date;
    private int addType = 1;
    public AddFavorView(@NonNull Context context,String date) {
        super(context);
        this.context = context;
        this.date = date;
        init();
    }


    private void init() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
        View view = inflater.inflate(R.layout.ui_add_favor_view, null);
        setContentView(view);
        TextView tvLeft = view.findViewById(R.id.tvBtnLeft);
        TextView tvRight = view.findViewById(R.id.tvBtnRight);
        TextView dateTv = view.findViewById(R.id.date_addFavor);
        dateTv.setText(date);
        RadioGroup rgroup= findViewById(R.id.rgroup_addFavor);
        rgroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup rg,int checkedId) {
                switch(checkedId){
                    case R.id.ch1_addFavor:
                        addType = 1;
                        break;
                    case R.id.ch2_addFavor:
                        addType = 2;
                        break;
                }
            }
        });
        final EditText addName = view.findViewById(R.id.name_addFavor);
        final EditText addMoney = view.findViewById(R.id.money_addFavor);
        final EditText addReason = view.findViewById(R.id.reason_addFavor);
        WindowManager.LayoutParams layoutParams = this.getWindow().getAttributes();
        layoutParams.width = (int) (App.getInstance().getResources().getDisplayMetrics().widthPixels * 0.8);
        this.getWindow().setAttributes(layoutParams);
        tvLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        tvRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(addReason.getText().toString()) || TextUtils.isEmpty(addName.getText().toString()) || TextUtils.isEmpty(addMoney.getText().toString())){
                    Toast.makeText(context, "请填写完整", Toast.LENGTH_SHORT).show();
                    return;
                }
                dismiss();
                FavorBean bean = new FavorBean();
                bean.setReason(addReason.getText().toString());
                bean.setType(addType);
                bean.setName(addName.getText().toString());
                bean.setMoney(addMoney.getText().toString());
                bean.setDate(date);
                boolean isSuccess = DBHelper.getInstance().insertFavor(bean);
                Toast.makeText(context, isSuccess ? "添加成功" : "添加失败", Toast.LENGTH_SHORT).show();
                if (isSuccess){

                }
            }
        });
    }


    public void setClickListener(ClickListenerInterface clickListenerInterface) {
        this.clickListenerInterface = clickListenerInterface;
    }

    public class clickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.tvBtnLeft:
                    clickListenerInterface.doLeft();
                    break;
                case R.id.tvBtnRight:
                    clickListenerInterface.doRight();
                    break;
            }
        }
    }

    public interface ClickListenerInterface {
        void doLeft();

        void doRight();
    }
}