package com.llele.favornote.utils;


import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.llele.favornote.App;
import com.llele.favornote.R;


/**
 * 仿IOS的弹出框
 */


public class AlertView extends Dialog {

    private String title, message, buttonLeftText, buttonRightText;
    private ClickListenerInterface clickListenerInterface;
    private Context context;

    public AlertView(@NonNull Context context, String title, String message, String buttonLeftText, String buttonRightText) {
        super(context);
        this.context = context;
        this.message = message;
        this.title = title;
        this.buttonLeftText = buttonLeftText;
        this.buttonRightText = buttonRightText;
        init();
    }


    private void init() {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
        View view = inflater.inflate(R.layout.ui_alert_view, null);
        setContentView(view);
        TextView tvMessage = view.findViewById(R.id.tvMessage);
        TextView tvLeft = view.findViewById(R.id.tvBtnLeft);
        TextView tvRight = view.findViewById(R.id.tvBtnRight);
        TextView tvTitle = view.findViewById(R.id.tvTitle);
        if (TextUtils.isEmpty(title)) {
            tvTitle.setVisibility(View.GONE);
        } else {
            tvTitle.setText(title);
        }
        tvLeft.setText(buttonLeftText);
        tvRight.setText(buttonRightText);
        tvMessage.setText(message);
        tvLeft.setOnClickListener(new clickListener());
        tvRight.setOnClickListener(new clickListener());
        WindowManager.LayoutParams layoutParams = this.getWindow().getAttributes();
        layoutParams.width = (int) (App.getInstance().getResources().getDisplayMetrics().widthPixels * 0.8);
        this.getWindow().setAttributes(layoutParams);
    }


    public void setClickListener(ClickListenerInterface clickListenerInterface) {
        this.clickListenerInterface = clickListenerInterface;
    }

    public class clickListener implements View.OnClickListener {

        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.tvBtnLeft:
                    clickListenerInterface.doLeft();
                    break;
                case R.id.tvBtnRight:
                    clickListenerInterface.doRight();
                    break;
            }
        }
    }

    public interface ClickListenerInterface {
        void doLeft();

        void doRight();
    }
}