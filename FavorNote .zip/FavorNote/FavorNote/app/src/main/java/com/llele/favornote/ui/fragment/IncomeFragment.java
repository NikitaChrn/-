package com.llele.favornote.ui.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.adapter.FavorListAdapter;
import com.llele.favornote.adapter.ReasonAdapter;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.bean.FavorType;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.ui.SearchActivity;
import com.llele.favornote.widget.MyPopup;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.core.BasePopupView;
import com.lxj.xpopup.enums.PopupPosition;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.SimpleCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncomeFragment extends Fragment {
    private static final String TAG = "IncomeFragment";
    RecyclerView recyclerView;
    private List<FavorBean> data = new ArrayList<>();
    private LinearLayout titleLayout;
    private ImageView triangle;
    private List<String> typeData = new ArrayList<>();
    private List<FavorType> dataType = new ArrayList<>();
    private boolean isShowPopup = false;
    MyPopup mPopup;
    private ImageView searchView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_income, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        recyclerView = view.findViewById(R.id.recycler_income);
        titleLayout = view.findViewById(R.id.ll_income_layout);
        triangle = view.findViewById(R.id.icon_income_layout);
        searchView = view.findViewById(R.id.search_income);
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SearchActivity.class);
                startActivity(intent);
            }
        });
        titleLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isShowPopup) {
                    showPartShadow(titleLayout);
                    triangle.setImageResource(R.mipmap.icon_triangle_up);
                } else {
                    triangle.setImageResource(R.mipmap.icon_triangle_down);
                }
            }
        });

    }


    @Override
    public void onResume() {
        super.onResume();
        data.clear();
        typeData.clear();
        dataType.clear();
        data.addAll(DBHelper.getInstance().queryAllFavorByType(2));
        typeData.add("全部记录");
        if (data.size() > 0) {
            for (int i = 0; i < data.size(); i++) {
                FavorType favorType = new FavorType(data.get(i).getReason(), data.get(i).getDate());
                if (dataType.size() == 0) {
                    dataType.add(favorType);
                } else {
                    if (!dataType.contains(favorType)){
                        dataType.add(favorType);
                    }
                }
            }

        }
        handler.sendEmptyMessage(101);
    }

    FavorListAdapter adapter;
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 101) {
                adapter = new FavorListAdapter(data);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                adapter.setOnItemClick(new FavorListAdapter.OnItemClick() {
                    @Override
                    public void onClick(final int position) {
                        new XPopup.Builder(getActivity()).asConfirm("提示", "是否删除记录？",
                                new OnConfirmListener() {
                                    @Override
                                    public void onConfirm() {
                                        boolean isSuccess = DBHelper.getInstance().deleteRecordById(data.get(position).get_id());
                                        ToastUtils.showShort(isSuccess ? "删除成功！" : "删除失败！");
                                        if (isSuccess) {
                                            onResume();
                                        }
                                    }
                                })
                                .show();
                    }
                });
            }
        }
    };


    private void showPartShadow(final View v) {
        mPopup = (MyPopup) new XPopup.Builder(getContext())
                .atView(v)
                .popupPosition(PopupPosition.Bottom)
                .setPopupCallback(new SimpleCallback() {
                    @Override
                    public void onShow(BasePopupView popupView) {
                        isShowPopup = true;
                        triangle.setImageResource(R.mipmap.icon_triangle_up);
                    }

                    @Override
                    public void onDismiss(BasePopupView popupView) {
                        isShowPopup = false;
                        triangle.setImageResource(R.mipmap.icon_triangle_down);
                    }
                })
                .asCustom(new MyPopup(getActivity(), dataType));
        mPopup.show();
        mPopup.getAdapter().setOnItemClick(new ReasonAdapter.OnItemClick() {
            @Override
            public void onClick(View view, int position) {
                if (mPopup != null && mPopup.isShow()) {
                    mPopup.dismiss();
                }
                if (position == 0) {
                    handler.sendEmptyMessage(101);
                    return;
                }
                final List<FavorBean> da = new ArrayList<>();
                for (int i = 0; i < data.size(); i++) {
                    if (data.get(i).getReason().equals(dataType.get(position).getReason()) && data.get(i).getDate().equals(dataType.get(position).getDate())) {
                        da.add(data.get(i));
                    }
                }
                adapter = new FavorListAdapter(da);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                adapter.setOnItemClick(new FavorListAdapter.OnItemClick() {
                    @Override
                    public void onClick(final int position) {
                        new XPopup.Builder(getActivity()).asConfirm("提示", "是否删除记录？",
                                new OnConfirmListener() {
                                    @Override
                                    public void onConfirm() {
                                        boolean isSuccess = DBHelper.getInstance().deleteRecordById(da.get(position).get_id());
                                        ToastUtils.showShort(isSuccess ? "删除成功！" : "删除失败！");
                                        if (isSuccess) {
                                            onResume();
                                        }
                                    }
                                })
                                .show();
                    }
                });
            }
        });
    }

}
