package com.llele.favornote.widget;

import android.content.Context;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.adapter.ReasonAdapter;
import com.llele.favornote.bean.FavorType;
import com.lxj.xpopup.impl.PartShadowPopupView;

import java.util.List;

public class MyPopup extends PartShadowPopupView {

    List<FavorType> data;
    Context context;

    public MyPopup(@NonNull Context context, List<FavorType> data) {
        super(context);
        this.data = data;
        this.context = context;
        adapter = new ReasonAdapter(data);
    }

    @Override
    protected int getImplLayoutId() {
        return R.layout.popuplayout_income;
    }

    RecyclerView mRecyclerView;
    ReasonAdapter adapter;

    @Override
    protected void onCreate() {
        super.onCreate();
        Log.e("tag", "CustomPartShadowPopupView onCreate");
        mRecyclerView = findViewById(R.id.recycler_income_reason);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(context));
    }


    public ReasonAdapter getAdapter() {
        return adapter;
    }

    @Override
    protected void onShow() {
        super.onShow();
        Log.e("tag", "CustomPartShadowPopupView onShow");
    }

    @Override
    protected void onDismiss() {
        super.onDismiss();
        Log.e("tag", "CustomPartShadowPopupView onDismiss");
    }
}
