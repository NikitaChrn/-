package com.llele.favornote.ui.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.adapter.CostListAdapter;
import com.llele.favornote.adapter.ExpandAdapter;
import com.llele.favornote.adapter.FavorListAdapter;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.bean.ListParentBean;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.ui.AddRecordActivity;
import com.llele.favornote.ui.SearchActivity;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 支出
 */
public class CostFragment extends Fragment {
    private static final String TAG = "CostFragment";
    RecyclerView recyclerView;
    private List<FavorBean> data = new ArrayList<>();
    private ExpandableListView expandView;
    private List<ListParentBean> parents = new ArrayList<>();
    private List<String> yearsData = new ArrayList<>();
    private ImageView searchView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_cost, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        recyclerView = view.findViewById(R.id.recycler_cost);
        expandView = view.findViewById(R.id.expandList_cost);
        searchView = view.findViewById(R.id.search_cost);
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), SearchActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        data.clear();
        parents.clear();
        yearsData.clear();
        data.addAll(DBHelper.getInstance().queryAllFavorByType(1));
        Collections.sort(data, new Comparator<FavorBean>() {
            @Override
            public int compare(FavorBean o1, FavorBean o2) {
                return o1.getDate().replace("-", "").compareTo(o2.getDate().replace("-", ""));
            }
        });
        if (data.size() > 0) {
            for (int i = 0; i < data.size(); i++) {
                if (yearsData.size() == 0) {
                    yearsData.add(data.get(i).getYear());
                    ListParentBean bean = new ListParentBean();
                    List<FavorBean> tempData = new ArrayList<>();
                    tempData.add(data.get(i));
                    bean.setChild(tempData);
                    bean.setCount(tempData.size());
                    bean.setDate(data.get(i).getYear());
                    parents.add(bean);
                } else {
                    if (!yearsData.contains(data.get(i).getYear())) {
                        yearsData.add(data.get(i).getYear());
                        ListParentBean bean = new ListParentBean();
                        List<FavorBean> tempData = new ArrayList<>();
                        tempData.add(data.get(i));
                        bean.setChild(tempData);
                        bean.setCount(tempData.size());
                        bean.setDate(data.get(i).getYear());
                        parents.add(bean);
                    } else {
                        int index = yearsData.indexOf(data.get(i).getYear());
                        ListParentBean bean = parents.get(index);
                        List<FavorBean> tempData = bean.getChild();
                        tempData.add(data.get(i));
                        bean.setDate(data.get(i).getYear());
                        bean.setChild(tempData);
                        bean.setCount(tempData.size());
                        parents.set(index, bean);
                    }
                }
            }
        }
        handler.sendEmptyMessage(101);
//        for (String name : yearsData) {
//            Log.e(TAG, "yearsData: " + name);
//        }
//        for (ListParentBean bean : parents) {
//            Log.e(TAG, "parents: " + bean.getDate() + " " + bean.getCount() + " " + bean.getChild().size());
//        }
    }


    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 101) {
                ExpandAdapter adapter = new ExpandAdapter(parents, getActivity());
                expandView.setAdapter(adapter);
                adapter.setOnItemClick(new ExpandAdapter.OnItemClick() {
                    @Override
                    public void click(final int id,final int groupPosition) {
                        new XPopup.Builder(getActivity()).asConfirm("提示", "是否删除记录？",
                                new OnConfirmListener() {
                                    @Override
                                    public void onConfirm() {
                                        boolean isSuccess = DBHelper.getInstance().deleteRecordById(id);
                                        ToastUtils.showShort(isSuccess ? "删除成功！" : "删除失败！");
                                        if (isSuccess) {
                                            onResume();
                                        }
                                    }
                                })
                                .show();
                    }
                });
//                final CostListAdapter adapter = new CostListAdapter(data);
//                recyclerView.setAdapter(adapter);
//                recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
//                adapter.setOnItemLongClick(new CostListAdapter.OnItemLongClick() {
//                    @Override
//                    public void onLongClick(final int position) {
//                        new XPopup.Builder(getActivity()).asConfirm("提示", "是否删除该记录？",
//                                new OnConfirmListener() {
//                                    @Override
//                                    public void onConfirm() {
//                                        boolean isSuccess = DBHelper.getInstance().deleteRecordById(data.get(position).get_id());
//                                        if (isSuccess) {
//                                            onResume();
//                                        }
//                                        ToastUtils.showShort(isSuccess ? "删除成功" : "删除失败");
//                                    }
//                                })
//                                .show();
//                    }
//                });

            }
        }
    };
}
