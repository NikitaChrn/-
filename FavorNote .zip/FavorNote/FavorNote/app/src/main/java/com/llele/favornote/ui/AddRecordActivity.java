package com.llele.favornote.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.blankj.utilcode.util.ToastUtils;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.utils.StatusBarUtil;
import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;
import com.lxj.xpopup.interfaces.OnSelectListener;

import java.util.Calendar;

public class AddRecordActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "AddRecordActivity";
    TextView commonTitle, choseFriendTypeTv, choseTypeTv, choseDateTv;
    EditText nameEdt, moneyEdt, remarksEdt;
    private int resultCodeType = 10010;
    private int resultCodeFriend = 10011;
    private Calendar mCalendar = null; // 日历
    private int mYear; // 年
    private int mMonth; // 月
    private int mDay; // 日
    private int addType = 1;
    private String dateStr = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
        dateStr = getIntent().getStringExtra("date");
        StatusBarUtil.setStatusBarMode(this, false, R.color.colorAccent);
        findViewById(R.id.back_common_header).setOnClickListener(this);
        commonTitle = findViewById(R.id.title_common_header);
        commonTitle.setText("添加记录");
        choseFriendTypeTv = findViewById(R.id.choseFriendType_addRecord);
        choseFriendTypeTv.setOnClickListener(this);
        choseTypeTv = findViewById(R.id.choseType_addRecord);
        choseTypeTv.setOnClickListener(this);
        choseDateTv = findViewById(R.id.choseDate_addRecord);
        choseDateTv.setOnClickListener(this);
        findViewById(R.id.save_addRecord).setOnClickListener(this);
        nameEdt = findViewById(R.id.nameEdt_addRecord);
        moneyEdt = findViewById(R.id.moneyEdt_addRecord);
        remarksEdt = findViewById(R.id.remarks_addRecord);
        mCalendar = Calendar.getInstance();
        // 获取当前对应的年、月、日的信息
        mYear = mCalendar.get(Calendar.YEAR);
        mMonth = mCalendar.get(Calendar.MONTH);
        mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
        choseDateTv.setText(dateStr);
        RadioGroup rgroup = findViewById(R.id.rgroup_addFavor);
        rgroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup rg, int checkedId) {
                switch (checkedId) {
                    case R.id.ch1_addFavor:
                        addType = 1;
                        break;
                    case R.id.ch2_addFavor:
                        addType = 2;
                        break;
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(AddRecordActivity.this, ChoseTypeActivity.class);
        ;
        switch (v.getId()) {
            case R.id.back_common_header:
                finish();
                break;
            case R.id.choseFriendType_addRecord:
                intent.putExtra("type", 1);
                startActivityForResult(intent, resultCodeFriend);
                break;
            case R.id.choseDate_addRecord:
                DatePickerDialog datePicker = new DatePickerDialog(AddRecordActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String m = "";
                        String d = "";
                        if ((monthOfYear + 1) < 10) {
                            m = "0" + (monthOfYear + 1);
                        } else {
                            m = "" + (monthOfYear + 1);
                        }
                        if (dayOfMonth < 10) {
                            d = "0" + dayOfMonth;
                        } else {
                            d = "" + dayOfMonth;
                        }
                        choseDateTv.setText(year + "-" + m + "-" + d);

                    }
                }, mYear, mMonth, mDay);
                datePicker.show();
                break;
            case R.id.choseType_addRecord:
                intent.putExtra("type", 2);
                startActivityForResult(intent, resultCodeType);
                break;
            case R.id.save_addRecord:
                if (TextUtils.isEmpty(nameEdt.getText().toString()) || choseFriendTypeTv.getText().toString().contains("请选择") || choseTypeTv.getText().toString().contains("请选择") || choseDateTv.getText().toString().contains("请选择") || TextUtils.isEmpty(moneyEdt.getText().toString()) || TextUtils.isEmpty(remarksEdt.getText().toString())) {
                    ToastUtils.showLong("请填写完整");
                    return;
                }
                new XPopup.Builder(AddRecordActivity.this).asConfirm("提示", "是否添加记录？",
                        new OnConfirmListener() {
                            @Override
                            public void onConfirm() {
                                FavorBean bean = new FavorBean();
                                bean.setPtype(choseFriendTypeTv.getText().toString());
                                bean.setRemarks(remarksEdt.getText().toString());
                                bean.setDate(choseDateTv.getText().toString());
                                bean.setMoney(moneyEdt.getText().toString());
                                bean.setName(nameEdt.getText().toString());
                                bean.setType(addType);
                                bean.setReason(choseTypeTv.getText().toString());
                                bean.setYear(choseDateTv.getText().toString().split("-")[0]);
                                boolean isSuccess = DBHelper.getInstance().insertFavor(bean);
                                ToastUtils.showShort(isSuccess ? "添加成功！" : "添加失败！");
                                if (isSuccess) {
                                    handler.sendEmptyMessageDelayed(101, 600);
                                }
                            }
                        })
                        .show();

                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == resultCodeFriend) {
                choseFriendTypeTv.setText(data.getExtras().getString("type"));
            } else if (requestCode == resultCodeType) {
                choseTypeTv.setText(data.getExtras().getString("type"));
            }
        }
    }

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            if (msg.what == 101) {
                finish();
            }
        }
    };
}