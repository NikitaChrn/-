package com.llele.favornote.widget;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.PopupWindow;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.adapter.ReasonAdapter;
import com.llele.favornote.bean.FavorType;

import java.util.List;

public class PopupwindowList extends PopupWindow {

    private int mWidth;
    private int mHeight;
    private View mContentView;
    private List<FavorType> mFileBeans;
    private RecyclerView mListView;
    //观察者模式
    public interface  OnSeletedListener{
        void onselected(FavorType bean);
    }
    private OnSeletedListener listener;
    public void setOnSelecterListener(OnSeletedListener listener){
        this.listener=listener;
    }
    public PopupwindowList(Context context,List<FavorType> mFileBeans) {
        super(context);
        this.mFileBeans=mFileBeans;
        calWidthAndHeight(context);
        setWidth(mWidth);
        setHeight(mHeight);
        this.setClippingEnabled(false);
        mContentView= LayoutInflater.from(context).inflate(R.layout.popuplayout_income,null);
        setContentView(mContentView);
        setFocusable(true);
        setTouchable(true);
        setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //点击PopupWindow以外区域时PopupWindow消失
                if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                    dismiss();
                }
                return false;
            }
        });
        initListView(context);
        initEvent();
    }

    private void initEvent() {

    }
    //初始化PopupWindow的listview
    private void initListView(Context context) {
//        ReasonAdapter adapter=new ReasonAdapter(mFileBeans);
//        mListView = mContentView.findViewById(R.id.recycler_income_reason);
//        mListView.setAdapter(adapter);
//        mListView.setLayoutManager(new LinearLayoutManager(context));
    }

    /**
     * 设置PopupWindow的大小
     * @param context
     */
    private void calWidthAndHeight(Context context) {
        WindowManager wm= (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics= new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);

        mWidth=metrics.widthPixels;
//        mHeight= (int) (metrics.heightPixels*0.7);
    }
}
