package com.llele.favornote.bean;

import java.util.Objects;

public class FavorType {
    String reason;
    String date;

    public FavorType(String type, String date) {
        this.reason = type;
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String name) {
        this.date = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof FavorType) {
            FavorType u = (FavorType) obj;
            return this.reason.equals(u.reason)
                    && this.date.equals(u.date);
        }
        return super.equals(obj);
    }

}
