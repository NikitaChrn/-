package com.llele.favornote;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.SPUtils;
import com.llele.favornote.constants.Api;
import com.llele.favornote.ui.fragment.CostFragment;
import com.llele.favornote.ui.fragment.IncomeFragment;
import com.llele.favornote.ui.fragment.MiddleFragment;
import com.llele.favornote.utils.StatusBarUtil;

import java.util.Arrays;


public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    private TextView iconIncome,iconCost,tvIncome,tvCost;
    private RelativeLayout middleTab;
    private CostFragment costFragment;
    private IncomeFragment incomeFragment;
    private MiddleFragment middleFragment;
    private FragmentManager fragmentManager;
    private ImageView costImg,incomeImg;
    private FragmentTransaction mFragmentTransaction;//fragment事务
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setStatusBar();
        setContentView(R.layout.activity_main);
        StatusBarUtil.setStatusBarMode(this, false, R.color.colorAccent);
        fragmentManager = getSupportFragmentManager();
        initView();
    }

    private void initView() {
        iconIncome = findViewById(R.id.icon_income);
        iconCost = findViewById(R.id.icon_cost);
        tvIncome = findViewById(R.id.tab_income);
        tvCost = findViewById(R.id.tab_cost);
        costImg = findViewById(R.id.image_cost);
        incomeImg = findViewById(R.id.image_income);
        LinearLayout incomeLayout = findViewById(R.id.ll_tab_income);
        LinearLayout costLayout = findViewById(R.id.ll_tab_cost);
        incomeLayout.setOnClickListener(this);
        costLayout.setOnClickListener(this);
        middleTab = findViewById(R.id.rl_middle_home);
        middleTab.setOnClickListener(this);
        middleTab.performClick();
        if (TextUtils.isEmpty(SPUtils.getInstance().getString(Api.SP_KEYS_REASON_TYPE))){
            String[] dataReason = new String[]{"婚礼","压岁","生日","生子","孝敬","其他"};
            String s = "";
            for (String str : dataReason) {
                s+=str+",";
            }
            SPUtils.getInstance().put(Api.SP_KEYS_REASON_TYPE,s);
        }
        if (TextUtils.isEmpty(SPUtils.getInstance().getString(Api.SP_KEYS_FRIEND_TYPE))){
            String[] dataFriend = new String[]{"朋友","同学","同事","亲戚","其他"};
            String s = "";
            for (String str : dataFriend) {
                s+=str+",";
            }
            SPUtils.getInstance().put(Api.SP_KEYS_FRIEND_TYPE, s);
        }
    }


    @Override
    public void onClick(View view) {
        mFragmentTransaction = fragmentManager.beginTransaction();
        hideFragment(mFragmentTransaction);
        switch (view.getId()){
            case R.id.ll_tab_income:
                if (incomeFragment == null){
                    incomeFragment = new IncomeFragment();
                    mFragmentTransaction.add(R.id.frame_main,incomeFragment);
                }else {
                    mFragmentTransaction.show(incomeFragment);
                    incomeFragment.onResume();
                }
//                iconIncome.setTextColor(getResources().getColor(R.color.colorAccent));
                incomeImg.setImageResource(R.mipmap.icon_income_selected);
                tvIncome.setTextColor(getResources().getColor(R.color.colorAccent));
//                iconCost.setTextColor(getResources().getColor(R.color.textGray));
                costImg.setImageResource(R.mipmap.icon_cost_unselected);
                tvCost.setTextColor(getResources().getColor(R.color.textGray));
                break;
            case R.id.ll_tab_cost:
                if (costFragment == null){
                    costFragment = new CostFragment();
                    mFragmentTransaction.add(R.id.frame_main,costFragment);
                }else {
                    mFragmentTransaction.show(costFragment);
                    costFragment.onResume();
                }

//                iconCost.setTextColor(getResources().getColor(R.color.colorAccent));
                costImg.setImageResource(R.mipmap.icon_cost_selected);
                tvCost.setTextColor(getResources().getColor(R.color.colorAccent));
//                iconIncome.setTextColor(getResources().getColor(R.color.textGray));
                incomeImg.setImageResource(R.mipmap.icon_income_unselected);
                tvIncome.setTextColor(getResources().getColor(R.color.textGray));
                break;
            case R.id.rl_middle_home:
                if (middleFragment == null){
                    middleFragment = new MiddleFragment();
                    mFragmentTransaction.add(R.id.frame_main,middleFragment);
                }else {
                    mFragmentTransaction.show(middleFragment);
                }
//                iconIncome.setTextColor(getResources().getColor(R.color.textGray));
//                iconIncome.setBackground(getResources().getDrawable(R.drawable.bg_22_666666));
                tvIncome.setTextColor(getResources().getColor(R.color.textGray));
//                iconCost.setTextColor(getResources().getColor(R.color.textGray));
//                iconCost.setBackground(getResources().getDrawable(R.drawable.bg_22_666666));
                tvCost.setTextColor(getResources().getColor(R.color.textGray));
                incomeImg.setImageResource(R.mipmap.icon_income_unselected);
                costImg.setImageResource(R.mipmap.icon_cost_unselected);
                break;
        }
        mFragmentTransaction.commit();
    }


    private void hideFragment(FragmentTransaction fragmentTransaction) {
        //如果此fragment不为空的话就隐藏起来
        if (middleFragment != null) {
            fragmentTransaction.hide(middleFragment);
        }
        if (incomeFragment != null) {
            fragmentTransaction.hide(incomeFragment);
        }
        if (costFragment != null) {
            fragmentTransaction.hide(costFragment);
        }
    }

}
