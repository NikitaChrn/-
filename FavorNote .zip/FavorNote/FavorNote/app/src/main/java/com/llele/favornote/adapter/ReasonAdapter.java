package com.llele.favornote.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.bean.FavorType;

import java.util.List;

public class ReasonAdapter extends RecyclerView.Adapter<ReasonAdapter.ReasonViewHolder> {
    private List<FavorType> data;

    public ReasonAdapter(List<FavorType> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ReasonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ReasonViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reason,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ReasonViewHolder holder, final int position) {
        holder.title.setText(data.get(position).getReason());
        holder.date.setText(data.get(position).getDate());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mOnItemClick.onClick(v,position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class ReasonViewHolder extends RecyclerView.ViewHolder{
        TextView title,date;
        public ReasonViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.reason_title);
            date = itemView.findViewById(R.id.reason_date);
        }
    }

    public interface OnItemClick{
        void onClick(View view,int position);
    }

    OnItemClick mOnItemClick;

    public void setOnItemClick(OnItemClick mOnItemClick){
        this.mOnItemClick = mOnItemClick;
    }
}
