package com.llele.favornote.widget;

import com.github.mikephil.charting.formatter.ValueFormatter;
import com.llele.favornote.bean.FavorBean;

import java.util.List;

public class BarChartXAxisFormatter extends ValueFormatter {
    private List<FavorBean> mLabels ;

    public BarChartXAxisFormatter(List<FavorBean> mLabels) {
        this.mLabels = mLabels;
    }


    @Override
    public String getFormattedValue(float value) {
        int v = (int) value;
        if(mLabels.size()==1){
            return mLabels.get(0).getName(); //避免当只有一个点时，入参value会出现 -1 0 1 BUG，异常；
        }else if (v < mLabels.size() && v >= 0) {
            return mLabels.get(v).getName();
        }else{
            return null;
        }
    }
}
