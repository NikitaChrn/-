package com.llele.favornote.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.llele.favornote.R;
import com.llele.favornote.adapter.SearchResultAdapter;
import com.llele.favornote.bean.FavorBean;
import com.llele.favornote.db.DBHelper;
import com.llele.favornote.ui.AddRecordActivity;
import com.llele.favornote.ui.SettingActivity;

import java.util.Calendar;
import java.util.List;

public class MiddleFragment extends Fragment {
    private static final String TAG = "MiddleFragment";
    private Calendar mCalendar = null; // 日历
    private int mYear; // 年
    private int mMonth; // 月
    private int mDay; // 日
    private String selectedDate = "";
    private FloatingActionButton fab;
    private ImageView togoSetting;
    private CalendarView calendarPicker;
    private RecyclerView recyclerView;
    private SearchResultAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_middle, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        // 获取日历对象
        mCalendar = Calendar.getInstance();
        // 获取当前对应的年、月、日的信息
        mYear = mCalendar.get(Calendar.YEAR);
        mMonth = mCalendar.get(Calendar.MONTH);
        mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
        selectedDate = mYear + "-" + (mMonth + 1) + "-" + mDay;
        // 获取CalendarView组件
        calendarPicker = view.findViewById(R.id.calendarPicker);
        recyclerView = view.findViewById(R.id.recycler_middle);
        calendarPicker.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                String m = "";
                String d = "";
                if ((month + 1) < 10) {
                    m = "0" + (month + 1);
                } else {
                    m = "" + (month + 1);
                }
                if (dayOfMonth < 10) {
                    d = "0" + dayOfMonth;
                } else {
                    d = "" + dayOfMonth;
                }
                selectedDate = year + "-" + m + "-" + d;
                List<FavorBean> da = DBHelper.getInstance().queryRecordByDate(selectedDate);
                adapter = new SearchResultAdapter(da);
                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                Log.e(TAG, "onSelectedDayChange: " + year + "-" + m + "-" + d +"----size="+ da.size());
            }
        });
        fab = view.findViewById(R.id.fab_main);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(new Intent(getActivity(), AddRecordActivity.class));
                intent.putExtra("date", selectedDate);
                startActivity(intent);
            }
        });
        togoSetting = view.findViewById(R.id.togoSetting_middle);
        togoSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), SettingActivity.class));
            }
        });
        List<FavorBean> data = DBHelper.getInstance().queryRecordByDate(selectedDate);
        adapter = new SearchResultAdapter(data);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

    }


}
