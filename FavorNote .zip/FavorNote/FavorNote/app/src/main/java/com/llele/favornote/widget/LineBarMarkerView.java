package com.llele.favornote.widget;

import android.content.Context;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.utils.MPPointF;
import com.llele.favornote.R;
import com.llele.favornote.bean.FavorBean;

import java.text.DecimalFormat;
import java.util.List;

public class LineBarMarkerView extends MarkerView {
    private static final String TAG = "LineBarMarkerView";
    private TextView tvContent;
    private final ValueFormatter xAxisValueFormatter;
    private List<FavorBean> data;

    public LineBarMarkerView(Context context, ValueFormatter xAxisValueFormatter, List<FavorBean> data) {
        super(context, R.layout.custom_marker_view);
        this.data = data;
        this.xAxisValueFormatter = xAxisValueFormatter;
        tvContent = findViewById(R.id.tvContent);  //自定义标签框
    }

    // runs every time the MarkerView is redrawn, can be used to update the
    // content (user-interface)
    @Override
    public void refreshContent(Entry e, Highlight highlight) {
        //根据坐标轴数据内容，刷新marker标签显示内容
        String x = xAxisValueFormatter.getFormattedValue(e.getX());
        String date = "";
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getName().equals(x)) {
                date = data.get(i).getDate();
            }
        }
        String y = Float.toString(e.getY());
        tvContent.setText(String.format("%s\n%s元", date, y));
        super.refreshContent(e, highlight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2), -getHeight());
    }

}
